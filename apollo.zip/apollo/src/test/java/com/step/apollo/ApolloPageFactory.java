package com.step.apollo;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ApolloPageFactory {
    
	WebDriver driver;
	
	@FindBy(how=How.XPATH,using="//span[@class='icon-ic_account_white']")
	WebElement login_btn;
	
	@FindBy(how=How.NAME,using="mobileNumber") 
	WebElement Mnumber;
	
	@FindBy(how = How.CLASS_NAME,using="icon-ic_arrow_forward")
	WebElement Submit1;

	
	@FindBy(how=How.XPATH,using="/html/body/div[3]/div[3]/div/div/div/form/div[1]/div[1]/input") 
	WebElement otp;      
	
	@FindBy(how=How.CLASS_NAME,using="icon-ic_arrow_forward")
	WebElement Submit2;
	
	@FindBy(how=How.XPATH,using="//SPAN[@class='icon-ic_account_white']")
	WebElement profile;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div[1]/div[1]/div[1]/div/header/div[3]/div[2]/div/div/ul/li[1]/a")
	WebElement manag_profile;
	
	@FindBy(how=How.XPATH,using="//span[@class='icon-ic_fees']")
	WebElement payment;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div/div[2]/div/div/div[2]/div/div[1]/div/div/button[2]")
	WebElement save_cards;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div/div[2]/div/div/div[2]/div/div[1]/div/div/button[1]")
	WebElement payment_history;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div[1]/div[1]/div[1]/div/header/div[3]/div[2]/div/div/ul/li[2]/a/span[2]")
	WebElement address;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div/div[2]/div/div/div[2]/div/div[2]/button")
	WebElement add_address;
	
	@FindBy(how=How.XPATH,using="/html/body/div[7]/div[3]/div/div[2]/div/div[2]/button[1]")
	WebElement chng_btn;
	
	@FindBy(how=How.XPATH,using="/html/body/div[7]/div[3]/div/div[2]/div/div/div[2]/div/input")
	WebElement pincode;
	
	@FindBy(how=How.XPATH,using="/html/body/div[5]/div[3]/div/div[2]/div/div[2]/button[2]")
	WebElement cnf_location;
		
	@FindBy(how=How.XPATH,using="/html/body/div[5]/div[3]/div/div[2]/div[1]/div[1]/div[1]/div/div/textarea[1]")
	WebElement input_HouseNo;
	
	@FindBy(how=How.XPATH,using="/html/body/div[5]/div[3]/div/div[2]/div[1]/div[1]/div[6]/div/div[2]/button")
	WebElement select_nick_name;
	
	@FindBy(how=How.XPATH,using="/html/body/div[5]/div[3]/div/div[2]/div[2]/button")
	WebElement save_address;
	
	@FindBy(how=How.XPATH,using="//span[@class='icon-ic_round_live_help']")
	WebElement need_help;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div/div[2]/div/div/div[2]/div/div[1]/div/div/div[1]/div/button[3]")
	WebElement requirment;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div/div[2]/div/div/div[2]/div/div[1]/div/div/div[2]/div/div/div/span")
	WebElement query_reason;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"menu-\"]/div[3]/ul/li[4]")
	WebElement select_query;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div/div[2]/div/div/div[2]/div/div[1]/div/div/div[3]/div/div/div/input")
	WebElement query_gmail;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div/div[2]/div/div/div[2]/div/div[1]/div/div/div[4]/div/div/div/input")
	WebElement query_comment;
	
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div/div[2]/div/div/div[2]/div/div[2]/button[2]")
	WebElement submit_query;       
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div/div[2]/div/div/div[2]/div/div[1]/div[1]/div[2]/div/div[2]/div[1]/div[2]/div")
	WebElement self;
	
	@FindBy(how=How.XPATH,using="/html/body/div[4]/div[3]/div/div[2]/div/div[2]/button[2]")
	WebElement save1;
	
	@FindBy(how=How.XPATH,using="/html/body/div[4]/div[3]/div/div[2]/div/div[2]/button[2]")
	WebElement save_new_user;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div/div[2]/div/div/div[2]/div/div[2]/button")
	WebElement add_new_user;
	
	@FindBy(how=How.XPATH,using="/html/body/div[4]/div[3]/div/div[2]/div/div[1]/div/div[1]/div/div/div[2]/div[1]/div/div/input")
	WebElement fst_Nm;
	
	@FindBy(how=How.XPATH,using="/html/body/div[4]/div[3]/div/div[2]/div/div[1]/div/div[1]/div/div/div[2]/div[2]/div[1]/div/input")
	WebElement lst_Nm;

	@FindBy(how=How.XPATH,using="/html/body/div[4]/div[3]/div/div[2]/div/div[1]/div/div[1]/div/div/div[2]/div[3]/div[1]/div/input")
	WebElement d_o_b;
	
	@FindBy(how=How.XPATH,using="/html/body/div[4]/div[3]/div/div[2]/div/div[1]/div/div[1]/div/div/div[2]/div[4]/div/div[1]/button")
	WebElement gender;
	
	@FindBy(how=How.XPATH,using="/html/body/div[4]/div[3]/div/div[2]/div/div[1]/div/div[1]/div/div/div[3]/div")
	WebElement relation;
	

	@FindBy(how=How.XPATH,using="//*[@id=\"menu-\"]/div[3]/ul/li[1]")
	WebElement relation_options;
	
	
	@FindBy(how=How.XPATH,using="/html/body/div[5]/div[3]/div/div[2]/div/div[2]/button[2]")
	WebElement confirm;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div[1]/div[1]/div[1]/div/header/div[3]/div[2]/div/div/ul/li[7]/a")
	WebElement logout;  
	
	@FindBy(how=How.XPATH,using="/html/body/div[4]/div[3]/div/div/div[3]/button/span[1]")
	WebElement ok;
	
	@FindBy(how=How.XPATH,using="(//SPAN[@class='icon-ic_arrow_right'])[5]")
	WebElement OneApollo;
	
	@FindBy(how=How.XPATH,using="//SPAN[@class='MuiTab-wrapper'][text()='My Membership']")
	WebElement MyMembership;
	
	@FindBy(how=How.XPATH,using="//H2[@class='MuiTypography-root MuiTypography-body1'][text()='Sanjeev Ojha']")
	WebElement Member;
	
	//  //*[@id="__next"]/div/div[2]/div/div[2]/div/div[1]/div/div[1]/div/h2
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div/div[2]/div/div[2]/div/div[1]/div/div[1]/div/p")
	WebElement Membership_Card;
	
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div/div[2]/div/div[2]/div/div[2]/div[1]/div/div/button[2]/span[1]")
	WebElement MyTransactions;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div/div[2]/div/div[2]/div/div[2]/div[2]/div/ul/li")
	WebElement Trans_history;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div/div[2]/div/div[2]/div/div[2]/div[2]/div/div/div[1]/h2")
	WebElement Earn;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"__next\"]/div/div[2]/div/div[2]/div/div[2]/div[2]/div/div/div[2]/h2")
	WebElement Redeem;
	
	 
	
	public ApolloPageFactory(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	public void Log_icon() throws InterruptedException {
		Thread.sleep(2000);
		System.out.println("login btn click");
		login_btn.click();
	}
	
    public void Mobile(String No) {
    	Mnumber.clear();
    	Mnumber.sendKeys(No);
	}
	
    public void Next() throws InterruptedException{
    	Thread.sleep(2000);
    	Submit1.click();
	}
	
    public void Validation(String code) throws InterruptedException {
    	Thread.sleep(2000);
       otp.sendKeys(code);
	}
    
    public void Arrow2() {
		Submit2.click();
	}
    
    public void User() throws InterruptedException {
    	Thread.sleep(2000);
    	profile.click();
	}
    
    public void Manage_user() {
		manag_profile.click();
	}
    
    public void Edit() throws InterruptedException {
    	Thread.sleep(2000);
    	self.click();

    	Thread.sleep(2000);
    	save1.click();
    	
    	Thread.sleep(2000);
    	ok.click();
    	
    }
    
    public void Add_user() throws InterruptedException {
    	Thread.sleep(2000);
    	add_new_user.click();
    }
    
    public void rel() throws InterruptedException {
    	JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("scroll(0,500)", "");
    	Thread.sleep(2000);
    	
    	relation.click();
    	relation_options.click();
    	Thread.sleep(2000);
    	save_new_user.click();
    	
    	Thread.sleep(2000);
    	confirm.click();
    	
    }
    
    public void location() throws InterruptedException {
    	JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("scroll(0,350)", "");
    	Thread.sleep(2000);
    	cnf_location.click();
    }
  
    
    public void Pay() throws InterruptedException {
    	Thread.sleep(2000);
		payment.click();
	}
    
    public void Cards() {
		save_cards.click();
	}
    
    public void Pay_history() {
		payment_history.click();
	}
    
    public void Area() {
		address.click();
	}
    
    public void Add_area() {
    	add_address.click();
		
	}
    
    public void Query() {
		
    	need_help.click();
	}
    
    public void Req() {
    	requirment.click();
    }
    
    public void Reason() {
    	query_reason.click();
    }
    
    public void Select_Reason() {
    	select_query.click();
    }
    
    public void Gmail(String g) {
    	query_gmail.sendKeys(g);
    	query_comment.click();
    }
    
    
    public void Qsubmit() {
    	submit_query.click();
    }
    
    public void close() {
    	
    	logout.click();
    }
    
    
    
    
}
