package com.step.apollo;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;


public class LoginAccount {
	public static WebDriver driver;
	ApolloPageFactory apollo;
	
	@Before
	public void launchBrowser() {

		ChromeOptions options = new ChromeOptions();
		HashMap<String, Integer> contentSettings = new HashMap<String, Integer>();
		HashMap<String, Object> profile = new HashMap<String, Object>();
		HashMap<String, Object> prefs = new HashMap<String, Object>();
		
		contentSettings.put("notifications", 2);
		profile.put("managed_default_content_settings", contentSettings);
		prefs.put("profile", profile);
		options.setExperimentalOption("prefs", prefs); 
		
		System.setProperty("webdriver.chrome.driver", "C:\\driver\\chromedriver.exe");

		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://www.apollopharmacy.in/");
		apollo = new ApolloPageFactory(driver);
		apollo = PageFactory.initElements(driver, ApolloPageFactory.class);

	}

	@Given("user is already on home page")
	public void user_is_already_on_home_page() {

		System.out.println("User is on HomePage");
		
	}

	@When("user click on login icon")
	public void user_click_on_login_icon() throws InterruptedException {

		apollo.Log_icon();
		
	}

	@Then("login pop up should occure")
	public void login_pop_up_should_occure() {
		System.out.println("Page Occured");
		
	}

	@When("user enter wrong number")
	public void user_enter_wrong_number(DataTable dataTable) throws InterruptedException {
		
		List<List<String>> Numberlist =dataTable.asLists(String.class);

		for(List<String> e : Numberlist) {
				
		//	apollo.Clear();
		//	Thread.sleep(4000);
			//apollo.Mobile(String.valueOf(e);
			System.out.println(e);
			System.out.println("This seems like wrong number for SignUp");
		}
	}

	
	@Then("next arrow key should not clickable")
	public void next_arrow_key_should_not_clickable() {
		
		if(apollo.Submit1.isEnabled()) {
		System.out.println("NextArrow key is not active");
		}
		else
		{
			System.out.println("NextArrow is active");
		}
		
	}

	@When("user enter valied mobile number")
	public void user_enter_valied_mobile_number() throws InterruptedException {
		apollo.Mnumber.clear();
		Thread.sleep(2000);
		apollo.Mobile("9123301775");
		
		
		
	}
	@And("click on login arrow")
	public void click_on_login_arrow() throws InterruptedException {
		apollo.Next();
	}

	@Then("user should be able to get otp")
	public void user_should_be_able_to_get_otp(){
		//driver.switchTo().frame("GTM-K3D3VVK");
		
		System.out.println("Otp Recieved");
	}

	@When("user enters otp and click on next arrow key")
	public void user_enters_otp_and_click_on_next_arrow_key() throws InterruptedException {
		
		Scanner input=new Scanner(System.in);
		System.out.println("Enter otp: ");
		Thread.sleep(3000);
		apollo.Validation(input.next());
		Thread.sleep(2000);
		apollo.Arrow2();

	}

	@Then("account should login successfully")
	public void account_should_login_successfully() {
		driver.getTitle();
		System.out.println("login_successfully");
	}

	@Given("user is already on manage profile page")
	public void user_is_already_on_manage_profile_page() throws InterruptedException {
	    //driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
	    Thread.sleep(3000);
		apollo.User();
		apollo.Manage_user();
	    
	}

	@When("user click on self")
	public void user_click_on_self() throws InterruptedException {
		apollo.Edit();
	    
	}

	@Given("Edit profile page pop up")
	public void edit_profile_page_pop_up() {
	    System.out.println("PopUp Occurred");
	}

	@Then("profile should be edited and saved")
	public void profile_should_be_edited_and_saved() {
		
	   System.out.println("Saved");
	}

	@When("user click on Add new profile")
	public void user_click_on_Add_new_profile() throws InterruptedException {
		
		apollo.Add_user();  
	}

	@Then("Add new member page should pop up")
	public void add_new_member_page_should_pop_up() {
        driver.getTitle();
		System.out.println("Page Occurred");
	}

	@Then("user can add details of new user")
	public void user_can_add_details_of_new_user() throws InterruptedException {

		apollo.fst_Nm.sendKeys("Aryan");
		apollo.lst_Nm.sendKeys("Dubey");
		apollo.d_o_b.sendKeys("25/09/2012");
		apollo.gender.click();
		apollo.rel();
	}
	
	
	@Given("user is already on Address book page")
	public void user_is_already_on_Address_book_page() throws InterruptedException {
		Thread.sleep(3000);
		apollo.User();
		apollo.Area();
	   
	}

	@When("user click on Add new address")
	public void user_click_on_Add_new_address() throws InterruptedException {
		Thread.sleep(2000);
		apollo.Add_area();

	}

	@Then("page should pop up for selecting gps location")
	public void page_should_pop_up_for_selecting_gps_location() {
		driver.getTitle();
		System.out.println("page occured");
		
	    
	}

	@Then("browser should give pop up for location\\/Gps permission")
	public void browser_should_give_pop_up_for_location_Gps_permission() {
		driver.getTitle();
		System.out.println("pop up occured");
	 
	}

	@When("user click on Allow")
	public void user_click_on_Allow() throws InterruptedException {
		Thread.sleep(2000);
		
	    
	}

	@Then("current location should tracked by gps")
	public void current_location_should_tracked_by_gps() {
		driver.getTitle();
		System.out.println("gps tracked");
	  
	}

	@When("user click on confirm location and proceed")
	public void user_click_on_confirm_location_and_proceed() throws InterruptedException {
		
		apollo.location();
	
	}

	@Then("Page should open with filled address")
	public void page_should_open_with_filled_address() {
		driver.getTitle();
		System.out.println("page occurred");

	}

	@When("user choose nickname for address")
	public void user_choose_nickname_for_address() throws InterruptedException {
		Thread.sleep(2000);
		apollo.input_HouseNo.sendKeys("17 Baikuntha ghosh road");
		Thread.sleep(2000);
		apollo.select_nick_name.click();

	}

	@Then("one out of three should get selected")
	public void one_out_of_three_should_get_selected() {
		System.out.println("selected -- Office");

	}

	@When("user click on save")
	public void user_click_on_save() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("scroll(0,350)", "");
		Thread.sleep(2000);
		apollo.save_address.click();
	    
	}

	@Then("address should added successfully")
	public void address_should_added_successfully() {
		String saved=driver.getTitle();
		System.out.println(saved);
	    
	}

     //Payment Part
	
	@When("user click on my payments")
	public void user_click_on_my_payments() {
	    WebElement My_Payments= driver.findElement(By.xpath("//SPAN[@class='jss455'][text()='My Payments']"));
	    My_Payments.click();
	}

	@When("user navigate to pharmacy payments")
	public void user_navigate_to_pharmacy_payments() throws InterruptedException {
	   Thread.sleep(2000);
	   apollo.Pay_history();
	}

	@Then("payment history should displayed successfully")
	public void payment_history_should_displayed_successfully() throws InterruptedException {
		Thread.sleep(2000);
		String msg=driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div/div[2]/div/div[2]/div/div/div[2]")).getText();
		System.out.println(msg);
	   
	}

	@When("user navigate to manage payments")
	public void user_navigate_to_manage_payments() throws InterruptedException {
		Thread.sleep(2000);
		apollo.Cards();
	    
	}

	@Then("saved cards details should displayed successfully")
	public void saved_cards_details_should_displayed_successfully() throws InterruptedException {
		Thread.sleep(2000);
		String msg2=driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div/div[2]/div/div[2]/div/div/div[2]")).getText();
	    System.out.println(msg2);
	}
	
	
	@Given("user is already on OneApollo Membership Page")
	public void user_is_already_on_OneApollo_Membership_Page() throws InterruptedException {
		Thread.sleep(1500);
		driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div/div[1]/div/div[2]/div/div/div[5]/a/span[2]")).click();
	    
	}

	@When("user click on my transactions")
	public void user_click_on_my_transactions() throws InterruptedException {
	   Thread.sleep(1500);
	   apollo.MyTransactions.click();
	}

	@Then("transactions details should displayed")
	public void transactions_details_should_displayed() throws InterruptedException {
	    Thread.sleep(1500);
	    String Epoint=apollo.Earn.getText();
	    System.out.println("Total Earned points: "+Epoint);
	    
	    Thread.sleep(1500);
	    String Rpoint=apollo.Redeem.getText();
	    System.out.println("Total Redeemed points: "+Rpoint);
	    
	    Thread.sleep(1500);
	    String Thistory=apollo.Trans_history.getText();
	    System.out.println("Transaction history: "+Thistory);
	}

	@When("user click on my membership")
	public void user_click_on_my_membership() throws InterruptedException {
		Thread.sleep(1500);
		apollo.MyMembership.click();
	}

	@Then("user should get membership card details")
	public void user_should_get_membership_card_details() throws InterruptedException {
		Thread.sleep(1500);
		String Uname=apollo.Member.getText();
		System.out.println("User Name: "+Uname);
		
		Thread.sleep(1500);
		String Mcard=apollo.Membership_Card.getText();
		System.out.println("User Membership Card: "+Mcard);
	}


	@Given("user is already on need help page")
	public void user_is_already_on_need_help_page() throws InterruptedException {
		Thread.sleep(2000);
		apollo.User();
		apollo.Query();
	 
	}

	@When("user select need requirment category")
	public void user_select_need_requirment_category() throws InterruptedException {
		Thread.sleep(2000);
		apollo.Req();
	    
	}

	@Then("one out of four category should selected successfully")
	public void one_out_of_four_category_should_selected_successfully() throws InterruptedException {
		Thread.sleep(2000);
		String msg1=apollo.requirment.getText();
		System.out.println(msg1);
	  
	}

	@When("user click reason for query drop down")
	public void user_click_reason_for_query_drop_down() throws InterruptedException {
		Thread.sleep(2000);
		apollo.Reason();
	   
	}

	@Then("pop should occure with list of queries")
	public void pop_should_occure_with_list_of_queries() throws InterruptedException {
		Thread.sleep(2000);
		String msg3=driver.findElement(By.xpath("//ul[@class='MuiList-root MuiMenu-list MuiList-padding']")).getText();
		System.out.println(msg3);
	    
	}

	@When("user select any query")
	public void user_select_any_query() throws InterruptedException {
		Thread.sleep(2000);
		apollo.Select_Reason();
	  
	}

	@When("user enter wrong gamil")
	public void user_enter_wrong_gamil() throws InterruptedException {
		Thread.sleep(2000);
		Scanner in1=new Scanner(System.in);
		System.out.println("Enter Gmail: ");
		apollo.Gmail(in1.next());
		
		
		
	}

	@Then("alert msg should popup")
	public void alert_msg_should_popup() throws InterruptedException {
		Thread.sleep(2000);
		if(apollo.submit_query.isEnabled()) {
			System.out.println("gmail added");
		}
		else {
	    String alert_msg=driver.findElement(By.xpath("//p[@class='MuiFormHelperText-root Mui-error MuiFormHelperText-filled']")).getText();
	    System.out.println(alert_msg);
	    
		}
		
	}

	@When("user enter valied gmail id")
	public void user_enter_valied_gmail_id() throws InterruptedException {
		apollo.query_gmail.sendKeys(Keys.CONTROL + "a");
		apollo.query_gmail.sendKeys(Keys.DELETE);
		Thread.sleep(2000);
		Scanner in2=new Scanner(System.in);
		System.out.println("Enter gmail: ");
		Thread.sleep(3000);
		apollo.Gmail(in2.next());

	}

	@Then("gamil should added successfully")
	public void gamil_should_added_successfully() throws InterruptedException {
		Thread.sleep(2000);
		if(apollo.submit_query.isEnabled()) {
			System.out.println("Email Added Successfully");
		}
		else {
			System.out.println("you have entered wrong gmail");
		}
		
		apollo.query_comment.sendKeys("Not required");

	}

	@When("user click on submit")
	public void user_click_on_submit() throws InterruptedException {
		Thread.sleep(2000);
		apollo.Qsubmit();
	   
	}

	@Then("help request should submited successfully")
	public void help_request_should_submited_successfully() throws InterruptedException {
		Thread.sleep(2000);
		System.out.println("quey submited");
	  
	}

	@Given("account is login")
	public void account_is_login() throws InterruptedException {
		Thread.sleep(2000);
		apollo.User();
		System.out.println("Account is login");
	  
	}

	@When("user click on logout")
	public void user_click_on_logout() throws InterruptedException {
		Thread.sleep(2000);
	    apollo.close();
	    System.out.println("clicked on logout");
	}

	@Then("account should logout successfully")
	public void account_should_logout_successfully() throws InterruptedException {
		Thread.sleep(2000);
		apollo.Log_icon();
		Thread.sleep(2000);
		if(apollo.Mnumber.isEnabled()) {
			System.out.println("logout successfully");
		}
		else {
			System.out.println("error while logout");
		}
	 
	}


}