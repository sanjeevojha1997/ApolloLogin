package com.util.apollo;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;



@RunWith(Cucumber.class)
@CucumberOptions(
		junit= "--step-notifications",
	    plugin = {"junit:target/cucumber reports/cucumber.xml"},
		features="Feature11",
		glue={"com.step.apollo"},
		tags= {"@membership"},
		
		monochrome = true
		
		//publish = true,
		)
public class Testrunner {

}













//plugin = {"pretty","json:target/cucumber reports/cucmber2.json"},
//plugin = {"pretty","html:target/cucumber reports/report.html"},


